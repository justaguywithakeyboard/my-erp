import{W as n}from"./CtXYGDNs.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
