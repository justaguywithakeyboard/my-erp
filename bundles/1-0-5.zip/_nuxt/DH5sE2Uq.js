import{W as n}from"./BCdbR6Kf.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
